document.addEventListener('DOMContentLoaded', (event) => {
    const navLinks = document.querySelectorAll('.nav-link');
    
    function handleClick(event) {
        navLinks.forEach(link => link.style.color = '');
        
        event.currentTarget.style.color = 'red';
    }
    
    navLinks.forEach(link => link.addEventListener('click', handleClick));
});

document.addEventListener('DOMContentLoaded')